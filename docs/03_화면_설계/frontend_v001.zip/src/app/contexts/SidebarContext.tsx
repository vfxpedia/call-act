import { createContext, useContext, ReactNode, useState } from 'react';

interface SidebarContextType {
  isSidebarExpanded: boolean;
  setIsSidebarExpanded: (expanded: boolean) => void;
}

const SidebarContext = createContext<SidebarContextType>({ 
  isSidebarExpanded: false,
  setIsSidebarExpanded: () => {}
});

export const useSidebar = () => useContext(SidebarContext);

interface SidebarProviderProps {
  children: ReactNode;
}

export function SidebarProvider({ children }: SidebarProviderProps) {
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);
  
  return (
    <SidebarContext.Provider value={{ isSidebarExpanded, setIsSidebarExpanded }}>
      {children}
    </SidebarContext.Provider>
  );
}
