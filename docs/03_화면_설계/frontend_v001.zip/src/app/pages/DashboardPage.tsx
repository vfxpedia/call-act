import MainLayout from '../components/layout/MainLayout';
import { CheckCircle, Clock, XCircle, AlertCircle, ExternalLink, Star, TrendingUp, TrendingDown, Minus, Target, Users, BookOpen, Award, PlayCircle } from 'lucide-react';
import ConsultationDetailModal from '../components/modals/ConsultationDetailModal';
import AnnouncementModal from '../components/modals/AnnouncementModal';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { noticesData, consultationsData, frequentInquiriesData, employeesData, simulationsData } from '../../data/mockData';

const stats = {
  todayCalls: 127,
  completed: 95,
  pending: 12,
  incomplete: 20
};

const frequentInquiries = frequentInquiriesData;

// Mock 데이터에서 실제 우수 사원 추출 (rank 1, 2, 3)
const topEmployees = employeesData
  .filter(emp => emp.rank <= 3)
  .sort((a, b) => a.rank - b.rank)
  .map((emp, index) => {
    const titles = [
      `FCR ${emp.fcr}% 달성`, // 1위
      `평균 ${emp.avgTime} 처리 시간`, // 2위
      `월간 ${emp.consultations}건 상담` // 3위
    ];
    return {
      id: emp.id,
      name: emp.name,
      title: titles[index] || `FCR ${emp.fcr}% 달성`,
      team: emp.team,
      rank: emp.rank
    };
  });

const weeklyGoal = {
  target: 500,
  current: 389,
  percentage: 78
};

const teamStats = [
  { team: 'A팀', calls: 142, fcr: 94, color: '#0047AB' },
  { team: 'B팀', calls: 128, fcr: 89, color: '#34A853' },
  { team: 'C팀', calls: 119, fcr: 91, color: '#FBBC04' },
];

const consultationHistory = consultationsData.map(c => ({
  id: c.id,
  status: c.status,
  category: c.category,
  title: c.memo || '상담 내용',
  customer: c.customer,
  agent: c.agent,
  time: c.datetime.split(' ')[1],
  date: c.datetime.split(' ')[0],
  fcr: c.fcr,
  duration: c.duration
}));

export default function DashboardPage() {
  const navigate = useNavigate();
  const [selectedConsultation, setSelectedConsultation] = useState<any>(null);
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<any>(null);
  const [isAnnouncementModalOpen, setIsAnnouncementModalOpen] = useState(false);
  const [announcements, setAnnouncements] = useState(noticesData.slice(0, 5));

  // 현재 사용자 권한 확인 (localStorage에서)
  const userRole = localStorage.getItem('userRole') || 'employee';

  // localStorage에서 픽스된 공지사항 불러오기
  useEffect(() => {
    const saved = localStorage.getItem('pinnedAnnouncements');
    if (saved) {
      try {
        const pinnedAnnouncements = JSON.parse(saved);
        if (pinnedAnnouncements.length > 0) {
          const unpinnedDefaults = noticesData.filter(
            a => !pinnedAnnouncements.find((p: any) => p.id === a.id)
          );
          setAnnouncements([...pinnedAnnouncements.slice(0, 5), ...unpinnedDefaults].slice(0, 5));
        }
      } catch (e) {
        console.error('Failed to load pinned announcements', e);
      }
    }
  }, []);

  const handleConsultationClick = (consultation: any) => {
    setSelectedConsultation(consultation);
    setIsConsultationModalOpen(true);
  };

  const handleAnnouncementClick = (announcement: any) => {
    setSelectedAnnouncement(announcement);
    setIsAnnouncementModalOpen(true);
  };

  const handleNoticeClick = () => {
    if (userRole === 'admin') {
      navigate('/admin/notice');
    } else {
      navigate('/notice');
    }
  };

  return (
    <MainLayout>
      <div className="h-[calc(100vh-60px)] bg-[#F5F5F5] p-2 sm:p-4 overflow-hidden">
        <div className="h-full grid grid-cols-1 lg:grid-cols-2 gap-2 sm:gap-3">
          {/* 좌측 영역 (50%) */}
          <div className="flex flex-col gap-2 sm:gap-3 overflow-hidden">
            {/* KPI 카운팅 4개 (1x4 그리드) - 높이 축소 */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3 flex-shrink-0">
              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-[#666666] mb-0.5">총 상담</div>
                  <div className="text-lg sm:text-xl font-bold text-[#0047AB]">{stats.todayCalls}</div>
                </div>
                <div className="w-6 h-6 sm:w-7 sm:h-7 bg-[#E8F1FC] rounded-full flex items-center justify-center">
                  <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#0047AB]" />
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-[#666666] mb-0.5">완료</div>
                  <div className="text-lg sm:text-xl font-bold text-[#34A853]">{stats.completed}</div>
                </div>
                <div className="w-6 h-6 sm:w-7 sm:h-7 bg-[#E8F5E9] rounded-full flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#34A853]" />
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-[#666666] mb-0.5">대기중</div>
                  <div className="text-lg sm:text-xl font-bold text-[#FBBC04]">{stats.pending}</div>
                </div>
                <div className="w-6 h-6 sm:w-7 sm:h-7 bg-[#FFF9E6] rounded-full flex items-center justify-center">
                  <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#FBBC04]" />
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-[#666666] mb-0.5">미완료</div>
                  <div className="text-lg sm:text-xl font-bold text-[#EA4335]">{stats.incomplete}</div>
                </div>
                <div className="w-6 h-6 sm:w-7 sm:h-7 bg-[#FFEBEE] rounded-full flex items-center justify-center">
                  <XCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-[#EA4335]" />
                </div>
              </div>
            </div>

            {/* 공지사항 + 금주의 이슈 (스크롤 없이 5개 표시) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 flex-shrink-0">
              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3 flex flex-col">
                <div className="flex items-center justify-between mb-1.5 sm:mb-2 flex-shrink-0">
                  <h2 className="text-xs sm:text-sm font-bold text-[#333333] flex items-center gap-1">
                    📢 공지사항
                  </h2>
                  <button 
                    onClick={handleNoticeClick}
                    className="text-[10px] text-[#0047AB] hover:underline flex items-center gap-1"
                  >
                    더보기 <ExternalLink className="w-2.5 h-2.5" />
                  </button>
                </div>
                <div className="flex flex-col justify-between gap-1.5 flex-1">
                  {announcements.slice(0, 5).map((item) => (
                    <div 
                      key={item.id}
                      onClick={() => handleAnnouncementClick(item)}
                      className="p-1.5 rounded-lg bg-[#F8F9FA] border border-[#E0E0E0] hover:bg-[#E8F1FC] hover:border-[#0047AB] cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                          item.tag === '긴급' ? 'bg-[#FFEBEE] text-[#EA4335]' :
                          item.tag === '시스템' ? 'bg-[#FFF9E6] text-[#FBBC04]' :
                          'bg-[#E8F1FC] text-[#0047AB]'
                        }`}>
                          [{item.tag}]
                        </span>
                        <span className="text-[10px] text-[#999999]">{item.date}</span>
                      </div>
                      <div className="text-xs text-[#333333] font-medium line-clamp-1">{item.title}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3 flex flex-col">
                <h2 className="text-xs sm:text-sm font-bold text-[#333333] mb-1.5 sm:mb-2 flex items-center gap-1.5 flex-shrink-0">
                  <AlertCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0047AB]" />
                  자주 찾는 문의
                </h2>
                <div className="flex flex-col justify-between gap-1.5 flex-1">
                  {frequentInquiries.slice(0, 5).map((item) => (
                    <div 
                      key={item.id}
                      className="p-2 rounded-lg bg-[#F8F9FA] border border-[#E0E0E0] hover:bg-[#E8F1FC] hover:border-[#0047AB] cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-[#0047AB] font-bold">{item.keyword}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-[#666666]">인입</span>
                          <span className="text-xs font-bold text-[#0047AB]">{item.count}건</span>
                          {item.trend === 'up' && <TrendingUp className="w-3 h-3 text-[#34A853]"/>}
                          {item.trend === 'down' && <TrendingDown className="w-3 h-3 text-[#EA4335]"/>}
                          {item.trend === 'same' && <Minus className="w-3 h-3 text-[#999999]"/>}
                        </div>
                      </div>
                      <p className="text-[10px] text-[#666666] line-clamp-1">{item.question}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 우수사원 사례집 */}
            <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-2.5 flex-shrink-0">
              <h2 className="text-xs sm:text-sm font-bold text-[#333333] mb-1.5 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 text-[#FBBC04]" />
                우수사원 사례집
              </h2>
              <div className="grid grid-cols-3 gap-2">
                {topEmployees.map((item) => (
                  <div 
                    key={item.id}
                    className="bg-[#FFF9E6] border-l-4 border-[#FBBC04] p-2 rounded-lg hover:bg-[#FFF5D6] cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-1 mb-1">
                      <span className="font-bold text-xs text-[#333333]">{item.name}</span>
                      <span className="text-[10px] text-[#999999]">({item.team})</span>
                    </div>
                    <div className="text-xs text-[#666666] line-clamp-1">{item.title}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* 이번주 목표 달성률 + 팀별 통계 */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 flex-shrink-0">
              {/* 이번주 목표 달성률 */}
              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3">
                <h2 className="text-xs sm:text-sm font-bold text-[#333333] mb-2 flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0047AB]" />
                  이번주 목표 달성률
                </h2>
                <div className="space-y-2">
                  <div className="flex items-end justify-between">
                    <div>
                      <div className="text-[10px] text-[#666666] mb-1">진행률</div>
                      <div className="text-2xl font-bold text-[#0047AB]">{weeklyGoal.percentage}%</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-[#666666]">달성/목표</div>
                      <div className="text-xs font-bold text-[#333333]">{weeklyGoal.current} / {weeklyGoal.target}</div>
                    </div>
                  </div>
                  <div className="w-full h-3 bg-[#F5F5F5] rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-[#0047AB] to-[#4A90E2] rounded-full transition-all duration-500"
                      style={{ width: `${weeklyGoal.percentage}%` }}
                    ></div>
                  </div>
                  <div className="text-[10px] text-[#666666] text-center">
                    목표까지 <span className="font-bold text-[#0047AB]">{weeklyGoal.target - weeklyGoal.current}건</span> 남음
                  </div>
                </div>
              </div>

              {/* 팀별 통계 */}
              <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3">
                <h2 className="text-xs sm:text-sm font-bold text-[#333333] mb-2 flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0047AB]" />
                  팀별 통계
                </h2>
                <div className="space-y-2">
                  {teamStats.map((team, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <div 
                        className="w-2 h-2 rounded-full flex-shrink-0"
                        style={{ backgroundColor: team.color }}
                      ></div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <span className="text-xs font-bold text-[#333333]">{team.team}</span>
                          <span className="text-[10px] text-[#666666]">FCR {team.fcr}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#F5F5F5] rounded-full overflow-hidden">
                          <div 
                            className="h-full rounded-full transition-all duration-500"
                            style={{ 
                              width: `${(team.calls / Math.max(...teamStats.map(t => t.calls))) * 100}%`,
                              backgroundColor: team.color
                            }}
                          ></div>
                        </div>
                        <div className="text-[10px] text-[#999999] mt-0.5">{team.calls}건</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 교육 시뮬레이션 */}
            <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3 flex-shrink-0">
              <h2 className="text-xs sm:text-sm font-bold text-[#333333] mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-[#0047AB]" />
                교육 시뮬레이션
              </h2>
              
              <div className="grid grid-cols-2 gap-2">
                {/* 1열: 진행 현황 */}
                <div>
                  <div className="text-[10px] text-[#666666] mb-1.5 font-semibold">진행 현황</div>
                  <div className="space-y-1.5">
                    {simulationsData.filter(s => s.status === 'completed' || s.status === 'in-progress').map((sim) => (
                      <div 
                        key={sim.id}
                        className="p-2 rounded-lg bg-[#F8F9FA] border border-[#E0E0E0] hover:bg-[#E8F1FC] hover:border-[#0047AB] cursor-pointer transition-all"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-1.5 flex-1 min-w-0">
                            {sim.status === 'completed' && <Award className="w-3 h-3 text-[#34A853] flex-shrink-0" />}
                            {sim.status === 'in-progress' && <PlayCircle className="w-3 h-3 text-[#0047AB] flex-shrink-0" />}
                            <span className="text-xs font-medium text-[#333333] line-clamp-1">{sim.title}</span>
                          </div>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium flex-shrink-0 ${
                            sim.status === 'completed' ? 'bg-[#E8F5E9] text-[#34A853]' : 'bg-[#E8F1FC] text-[#0047AB]'
                          }`}>
                            {sim.status === 'completed' ? `${sim.score}점` : `${sim.progress}%`}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-[#999999]">
                          <span className={`px-1.5 py-0.5 rounded ${
                            sim.difficulty === 'easy' ? 'bg-[#E8F5E9] text-[#34A853]' :
                            sim.difficulty === 'medium' ? 'bg-[#FFF9E6] text-[#FBBC04]' :
                            'bg-[#FFEBEE] text-[#EA4335]'
                          }`}>
                            {sim.category}
                          </span>
                          <span>• {sim.duration}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2열: 추천 시뮬레이션 */}
                <div>
                  <div className="text-[10px] text-[#666666] mb-1.5 font-semibold">추천 시뮬레이션</div>
                  <div className="space-y-1.5">
                    {simulationsData.filter(s => s.status === 'recommended').slice(0, 3).map((sim) => (
                      <div 
                        key={sim.id}
                        className="p-2 rounded-lg bg-gradient-to-r from-[#FFF9E6] to-[#FFFBF0] border border-[#FBBC04] hover:shadow-md cursor-pointer transition-all"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-1.5 flex-1 min-w-0">
                            <Star className="w-3 h-3 text-[#FBBC04] flex-shrink-0" />
                            <span className="text-xs font-medium text-[#333333] line-clamp-1">{sim.title}</span>
                          </div>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-white text-[#FBBC04] font-medium flex-shrink-0">
                            추천
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-[#999999]">
                          <span className={`px-1.5 py-0.5 rounded ${
                            sim.difficulty === 'easy' ? 'bg-[#E8F5E9] text-[#34A853]' :
                            sim.difficulty === 'medium' ? 'bg-[#FFF9E6] text-[#FBBC04]' :
                            'bg-[#FFEBEE] text-[#EA4335]'
                          }`}>
                            {sim.category}
                          </span>
                          <span>• {sim.duration}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 우측 영역 - 상담 내역 (50%, 전체 높이) */}
          <div className="bg-white rounded-lg shadow-sm border border-[#E0E0E0] p-2 sm:p-3 flex flex-col overflow-hidden">
            <div className="flex items-center justify-between mb-1.5 sm:mb-2 flex-shrink-0">
              <h2 className="text-xs sm:text-sm font-bold text-[#333333]">📋 상담 내역</h2>
              <button 
                onClick={() => navigate('/consultation/history')}
                className="text-[10px] text-[#0047AB] hover:underline flex items-center gap-1"
              >
                전체보기 <ExternalLink className="w-2.5 h-2.5" />
              </button>
            </div>
            
            <div className="flex-1 flex flex-col gap-1.5 overflow-hidden">
              {consultationHistory.slice(0, 20).map((item) => (
                <div 
                  key={item.id}
                  onClick={() => handleConsultationClick(item)}
                  className="flex items-center gap-1.5 sm:gap-2 p-1.5 sm:p-2 rounded-lg border border-[#F0F0F0] hover:bg-[#F8F9FA] hover:border-[#E0E0E0] cursor-pointer transition-all flex-shrink-0"
                >
                  <div className={`flex-shrink-0 w-[45px] sm:w-[50px] px-1 sm:px-1.5 py-0.5 rounded text-[10px] font-medium text-center ${
                    item.status === '완료' ? 'bg-[#E8F5E9] text-[#34A853]' :
                    item.status === '진행중' ? 'bg-[#E3F2FD] text-[#0047AB]' :
                    'bg-[#F5F5F5] text-[#999999]'
                  }`}>
                    {item.status}
                  </div>
                  <div className="flex-shrink-0 w-[60px] sm:w-[70px]">
                    <span className="text-[10px] px-1.5 py-0.5 bg-[#E8F1FC] text-[#0047AB] rounded block text-center truncate">
                      {item.category}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-[#333333] line-clamp-1">{item.title}</div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] text-[#666666] truncate">{item.customer}</span>
                      <span className="text-[10px] text-[#999999]">{item.time}</span>
                    </div>
                  </div>
                  {item.fcr && (
                    <div className="flex-shrink-0 w-4 h-4 bg-[#34A853] text-white rounded-full flex items-center justify-center text-[9px]">
                      ✓
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {selectedConsultation && (
        <ConsultationDetailModal
          isOpen={isConsultationModalOpen}
          onClose={() => setIsConsultationModalOpen(false)}
          consultation={selectedConsultation}
        />
      )}

      {selectedAnnouncement && (
        <AnnouncementModal
          isOpen={isAnnouncementModalOpen}
          onClose={() => setIsAnnouncementModalOpen(false)}
          announcement={selectedAnnouncement}
        />
      )}
    </MainLayout>
  );
}