import { ReactNode, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';
import { useSidebar } from '../../contexts/SidebarContext';

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { isSidebarExpanded, setIsSidebarExpanded } = useSidebar();
  const location = useLocation();

  // 페이지 이동 시 사이드바 축소
  useEffect(() => {
    setIsSidebarExpanded(false);
  }, [location.pathname, setIsSidebarExpanded]);

  // 디버깅: 상태 변경 확인
  useEffect(() => {
    console.log('MainLayout - isSidebarExpanded:', isSidebarExpanded);
  }, [isSidebarExpanded]);

  const handleMouseEnter = () => {
    console.log('Sidebar mouseEnter triggered');
    setIsSidebarExpanded(true);
  };

  const handleMouseLeave = () => {
    console.log('Sidebar mouseLeave triggered');
    setIsSidebarExpanded(false);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      <Header />
      
      <Sidebar 
        isExpanded={isSidebarExpanded}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      />
      
      {/* 사이드바가 항상 표시되므로 메인 콘텐츠에 왼쪽 마진 추가 (데스크톱만) */}
      <main className={`mt-[60px] transition-all duration-300 ${isSidebarExpanded ? 'lg:ml-[200px]' : 'lg:ml-[56px]'}`}>
        {children}
      </main>
    </div>
  );
}